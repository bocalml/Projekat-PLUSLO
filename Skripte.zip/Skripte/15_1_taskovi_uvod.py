'''from qgis.core import (
  QgsProcessingContext,
  QgsTaskManager,
  QgsTask,
  QgsProcessingAlgRunnerTask,
  Qgis,
  QgsProcessingFeedback,
  QgsApplication,
  QgsMessageLog,
)'''  # ukoliko je standalone

# nacini na koje se sve moze kreirati task

# pomocu klase QgsTask
class PosebanTask(QgsTask):
    pass

# kreiranje taska iz funkcije
def intenzivnaFunkcija():
    # odredjeno izvrsavanje naredbi koje opterecuje procesor
    pass
    
def posao_obavljen():
    # ...koriscenje dobijenih rezultata iz prethodne funkcije
    pass
    
task = QgsTask.fromFunction('intenzivna funkcija', intenzivnaFunkcija, onfinished=posao_obavljen)


# kreiranje taska iz algoritama za obradu (procesiranje)
parametri = dict()
kontekst = QgsProcessingContext()
povratna_informacija = QgsProcessingFeedback()

bafer = QgsApplication.instance().processingRegistry().algorithmById('native:buffer')
task = QgsProcessingAlgRunnerTask(bafer, parametri, kontekst, povratna_informacija)






































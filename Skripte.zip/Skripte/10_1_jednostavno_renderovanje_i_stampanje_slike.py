# uzima odredjeni lejer i na osnovu njega kreira sliku

import os

lokacija_slike = os.path.join(QgsProject.instance().homePath(), 'D:/Fakultet/Master/Upravljanje_GIS_projektima/Projekat_PLUSLO/Podaci_QGIS/render.png')

lejer = QgsProject.instance().mapLayersByName('Geologija_kopija')[0]
settings = QgsMapSettings()
settings.setLayers([lejer])
settings.setBackgroundColor(QColor(255, 255, 255))
settings.setOutputSize(QSize(800, 600))
settings.setExtent(lejer.extent())

render = QgsMapRendererParallelJob(settings)

def zavrsen():
    slika = render.renderedImage()
    # cuvanje slike
    slika.save(lokacija_slike, 'png')

render.finished.connect(zavrsen)

# Zapocinje renderovanje
render.start()

# ukoliko je standalone skripta, neophodno je importovati ovaj modul
# zbog specificne petlje (posto je ova skripta pisana da se pokrece
# unutar samog QGIS-a, nema potrebe da se importuje)
# from qgis.PyQt5.QtCore import QEventLoop
petlja = QEventLoop()
render.finished.connect(petlja.quit)
petlja.exec_()


# ukoliko imamo vise razlicitih lejera, u razlicitim koordinatnim sistemima
# neophodno je da namestimo koordinatni sistem u kom zelimo da lejer bude prikazan
# lejeri = [iface.activeLayer()]
# settings.setLayers(lejeri)
# settings.setDestinationCrs(lejeri[0].crs())









import os #potrebno i u QGIS-u
# from qgis.core import (QgsVectorLayer) - potrebno u standalone

# Uzima lejer na toj lokaciji
putanja_do_geologije = 'D:/Fakultet/Master/Upravljanje_GIS_projektima/Projekat_PLUSLO/Podaci_QGIS/Geologija.shp'

# Format je:
# vlayer = QgsVectorLayer(data_source, layer_name, provider_name)
vlayer = QgsVectorLayer(putanja_do_geologije, 'Geologija', 'ogr')

# Proverava da li je lejer uspesno ucitan
if not vlayer.isValid():
    print('Lejer nije uspesno ucitan')
else:
    QgsProject.instance().addMapLayer(vlayer)

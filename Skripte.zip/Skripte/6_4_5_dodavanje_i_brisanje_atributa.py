# from qgis.PyQt.QtCore import QVariant (ukoliko smo izvan qgis-a)

# korisceni lejer = Corine_Lo_Kopija
lejer = iface.activeLayer()
caps = lejer.dataProvider().capabilities()

# dodaje atribute izabranom lejeru
if caps and QgsVectorDataProvider.AddAttributes:
    res = lejer.dataProvider().addAttributes(
    [QgsField('Opis', QVariant.String),
    QgsField('Povrs_ha', QVariant.Int)])

# brise atribut na osnovu njegovog indeksa
# ukloniti '#' da bi se izvrsilo brisanje
# if caps and QgsVectorDataProvider.DeleteAttributes:
    # res = lejer.dataProvider().deleteAttributes([7])
    
# alternativne metode za brisanje atributa
lejer.dataProvider().addAttributes([QgsField('f1', QVariant.Int), \
QgsField('f2', QVariant.Int), QgsField('f3', QVariant.Int)])
lejer.updateFields()       # azurira dodate/obrisane atribute
# stampa atribute koji su trenutno dodeljeni lejeru
for atribut in lejer.fields():
    print(atribut.name())
print('--------------------------')
count = lejer.fields().count() # vraca broj atributa u lejeru
lista_indeksa = list((count-3, count-2))

# brise jedan atribut pomocu indeksa
lejer.dataProvider().deleteAttributes([count-1])

# brise vise atributa pomocu liste sa indeksima
lejer.dataProvider().deleteAttributes(lista_indeksa)
lejer.updateFields()

for atribut in lejer.fields():
    print(atribut.name())


    
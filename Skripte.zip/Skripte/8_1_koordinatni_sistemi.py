'''from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsPointXY,
)''' # ukoliko je standalone skripta


crs = QgsCoordinateReferenceSystem('EPSG:6316')
# stampa 
print(crs.isValid())

wkt = 'GEOGCS["WGS84", DATUM["WGS84", SPHEROID["WGS84", 6378137.0, 298.257223563]],' \
      'PRIMEM["Greenwich", 0.0], UNIT["degree",0.017453292519943295],' \
      'AXIS["Longitude",EAST], AXIS["Latitude",NORTH]]'
proj = '+proj=tmerc +lat_0=0 +lon_0=21 +k=0.9999 +x_0=7500000 +y_0=0 +ellps=bessel +towgs84=682,-203,480,0,0,0,0 +units=m +no_defs'

crs2 = QgsCoordinateReferenceSystem(proj)
print(crs2.isValid())
# iz nekog razloga, stampa False, mada su ovi parametri direktno 
# prekopirani iz QGIS-a i u sustini su ispravni

# komande za pristup informacijama o koordinatnom sistemu

print('QGIS CRS ID: ', crs.srsid())
print('PostGIS SRID: ', crs.postgisSrid())
print('Opis: ', crs.description())
print('Akronim projekcije: ', crs.projectionAcronym())
print('Akronim elipsoida: ', crs.ellipsoidAcronym())
print('Proj String: ', crs.toProj4())
# proverava da li je geografski ili projektovani koordinatni sistemi
print('Da li je geografski: ', crs.isGeographic())
# proverava mernu jedinicu za korisceni koordinatni sistem
print('Merna jedinica mape: ', crs.mapUnits())










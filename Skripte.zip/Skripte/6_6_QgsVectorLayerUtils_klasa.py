# klasa QgsVectorLayerUtils
# sadrzi odredjene, korisne metode 
# vise o njoj na https://qgis.org/pyqgis/3.16/core/QgsVectorLayerUtils.html#qgis.core.QgsVectorLayerUtils

# priprema QgsFeature objekat da bude dodat lejeru
# zadrzavajuci sva ogranicenja i default vrednosti
# korisceni atribut Lo_granice
lejer = iface.activeLayer()
feat = QgsVectorLayerUtils.createFeature(lejer)


# getValues metod omogucava dobijanje vrednosti
# za odredjeni atribut ili izraz
lejer.selectByIds([0])
value = QgsVectorLayerUtils.getValues(lejer, 'opstina__1', selectedOnly=True)
print(value)
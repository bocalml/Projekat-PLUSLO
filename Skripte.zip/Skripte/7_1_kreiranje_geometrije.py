'''from qgis.core import (
  QgsGeometry,
  QgsPoint,
  QgsPointXY,
  QgsWkbTypes,
  QgsProject,
  QgsFeatureRequest,
  QgsVectorLayer,
  QgsDistanceArea,
  QgsUnitTypes,
  QgsCoordinateTransform,
  QgsCoordinateReferenceSystem
)''' 

# kreiranje geometrije iz koordinata
gTacka = QgsGeometry.fromPointXY(QgsPointXY(7367975,4941647))
print(gTacka)
gLinija = QgsGeometry.fromPolyline([QgsPoint(7365894,4949697), QgsPoint(7369230,4935285)])
print(gLinija)
gPoligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(7359602,4927949), 
QgsPointXY(7366506,4929147),
QgsPointXY(7364291.3,4924586.2)]
])
print(gPoligon)

# WKT - well-known text format (vise na https://en.wikipedia.org/wiki/Well-known_text_representation_of_geometry)
geom_iz_wkt = QgsGeometry.fromWkt('POINT(7364925.5 4942209.4)')
print(geom_iz_wkt)
# WKB - well-known binary format (https://mariadb.com/kb/en/well-known-binary-wkb-format/)
geom = QgsGeometry()
wkb = bytes.fromhex("010100000000000000000045400000000000001440")
geom.fromWkb(wkb)
print(geom.asWkt())



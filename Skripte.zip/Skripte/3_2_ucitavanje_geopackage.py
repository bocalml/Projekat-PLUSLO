import os
#from qgis.core import(QgsVectorLayer) - ukoliko je standalone

#putanja do gpkg
put_do_corine = os.path.join(QgsApplication.pkgDataPath(), 'resources', 'data', 'D:/Fakultet/Master/Upravljanje_GIS_projektima/Projekat_PLUSLO/Podaci_QGIS/Corine_gpkg.gpkg')

vlayer = QgsVectorLayer(put_do_corine, 'Corine_gpkg', 'ogr')

if not vlayer.isValid():
    print("Lejer nije uspesno ucitan")
else:
    QgsProject.instance().addMapLayer(vlayer)


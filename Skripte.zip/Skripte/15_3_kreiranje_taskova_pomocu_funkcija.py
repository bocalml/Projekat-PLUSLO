import random
from time import sleep

MESSAGE_CATEGORY = 'TaskFromFunction'

def uradiNesto(task, wait_time):
    # Podize izuzetak (exception), kako bi prekinuo task.
    # Ukoliko je task uspesno zavrsen, vraca odgovarajucu vrednost
    # rezultat ce biti prosledjen, zajedno sa izuzetkom
    # (ukoliko je uspesno zavrsen, vraca None), 'zavrseno' metodi
    
    QgsMessageLog.logMessage('Zapocinjem task {}'.format(
    task.description()), MESSAGE_CATEGORY, Qgis.Info)
    wait_time = wait_time/100
    ukupno = 0
    iteracije = 0
    for i in range(100):
        sleep(wait_time)
        task.setProgress(i)
        randomint = random.randint(0, 500)
        ukupno += randomint
        iteracije += 1
        if task.isCanceled():
            stopped(task)
            return None
        if randomint == 54:
            raise Exception('Losa vrednost')
            
    return {
    'ukupno': ukupno,
    'iteracije': iteracije,
    'task': task.description()
    }


def zaustavljeno(task):
    QgsMessageLog.logMessage(
    'Task "{}" je prekinut.'.format(
    task.description()),
    MESSAGE_CATEGORY, Qgis.Info
    )

def zavrseno(izuzetak, rezultat=None):
    # Poziva se kada se "uradiNesto" funkcija zavrsi.
    # Izuzetak (exception) nije None tipa, ukoliko
    # "uradiNesto" podigne izuzetak. 
    # result je povratna vrednost od "uradiNesto"
    
    if izuzetak is None:
        if rezultat is None:
            QgsMessageLog.logMessage(
            'Zavrseno bez izuzetaka i bez rezultata (verovatno prekinuto od strane korisnika)',
            MESSAGE_CATEGORY, Qgis.Warning)
        else:
            QgsMessageLog.logMessage(
            'Task "{}" je zavrsen.\nUkupno: {} (sa ukupnim brojem {} iteracija)'.format(
            rezultat['task'],
            rezultat['ukupno'],
            rezultat['iteracije']),
            MESSAGE_CATEGORY, Qgis.Info
            )
    else:
        QgsMessageLog.logMessage('Izuzetak: {}'.format(
        izuzetak), MESSAGE_CATEGORY, Qgis.Critical)
        raise izuzetak
            

task_1 = QgsTask.fromFunction('Koriscenje procesora 1', uradiNesto, on_finished=zavrseno, wait_time=5)
task_2 = QgsTask.fromFunction('Koriscenje procesora 2', uradiNesto, on_finished=zavrseno, wait_time=4)


QgsApplication.taskManager().addTask(task_1)
QgsApplication.taskManager().addTask(task_2)
 
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

















#from qgis.PyQt.QtCore import QVariant     # ukoliko je standalone


lejer = QgsVectorLayer('Point?crs=epsg:6316', 'naselja', 'memory')
pr = lejer.dataProvider()
pr.addAttributes(
[QgsField('naziv', QVariant.String),
QgsField('br_stanovnika', QVariant.Int),
QgsField('nm_visina', QVariant.Int),
QgsField('ukupni_stan', QVariant.Int),
QgsField('P_bafer', QVariant.Int)]
)

podaci = [
{'x': 7359186, 'y':4933535, 'ime': 'Loznica', 'stanovnici': 19572, 'visina': 141},
{'x': 7353475, 'y':4931713, 'ime': 'Banja Koviljaca', 'stanovnici': 5151, 'visina': 131},
{'x': 7366452, 'y':4946748, 'ime': 'Lesnica', 'stanovnici': 4276, 'visina': 107}
]

for podatak in podaci:
    f = QgsFeature()
    tacka = QgsPointXY(podatak['x'], podatak['y'])
    f.setGeometry(QgsGeometry.fromPointXY(tacka))
    f.setAttributes([podatak['ime'], podatak['stanovnici'], podatak['visina']])
    pr.addFeature(f)

lejer.updateExtents()
QgsProject.instance().addMapLayer(lejer)

# prvi izraz racuna ukupan broj stanovnika
# drugi izraz kreira bafer zonu oko tacaka, na osnovu 
# nadmorske visine a zatim racuna povrsinu te bafer zone
izraz1 = QgsExpression('sum("br_stanovnika")')
izraz2 = QgsExpression('area(buffer($geometry, "nm_visina"))')


# QgsExpressionContextUtils.globalProjectLayerScopes() je funkcija koja nam pomaze
# da dodamo globalni obim (scope), projekat, i lejere (unutar tog obima) u isto vreme
# Alternativno, oni se mogu rucno dodavati. Vazno zapamtiti, uvek se krece od najopstijeg
# do najspecificnijeg obimu (npr. od gobalnog, ka projektu, ka lejerima)
# vise o obimu na https://realpython.com/python-namespaces-scope/
context = QgsExpressionContext()
context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lejer))

with edit(lejer):
    for f in lejer.getFeatures():
        context.setFeature(f)
        f['ukupni_stan'] = izraz1.evaluate(context)
        f['P_bafer'] = izraz2.evaluate(context)
        lejer.updateFeature(f)

print(f['ukupni_stan'])
print(f['P_bafer'])

print('------------------------------')

# Prilikom izvrsavanja izraz ili njegovog rascljanjivanja
# moze doci do gresaka, pa je korisno isprobati i videti da li je sve u redu
# ukoliko nije, Pajton ce u ovom slucaju prijaviti da postoji greska
#izraz = QgsExpression('1+1=2')
#if exp.hasParserError():
    #raise Exception(exp.parserErrorString())

#vrednost = exp.evaluate()
#if vrednost.hasEvalError():
    #raise ValueError(exp.evalErrorString())





# korisceni lejer = ZPD_tacke_kopija
lejer = iface.activeLayer()
print(lejer.isEditable())

# skuplja FID-ove u listu
fidd = []
for feature in lejer.getFeatures():
    fidd.append(feature.id())
print(fidd)

feat1 = feat2 = QgsFeature(lejer.fields())
fid = -46 # 
feat1.setId(fid)

# dodaje dva featurea (instance QgsFeature)
# lejer.addFeatures([feat1,feat2])

# brise feature sa prethodno definisanim FID-om
# lejer.deleteFeature(fid)

# postavlja novu geometriju (instanca QgsGeometry) za feature
# moze se takodje koristiti QgsGeometry.fromPointXY(QgsPointXY(koordinate))
geom = QgsGeometry.fromWkt('POINT(7367184 4934895)')
lejer.changeGeometry(fid, geom)

# azurira atribut preko indeksa tog atributa
# za odredjenu vrednost
indeksAtributa = 1
vrednost = 'Spomenik'
lejer.changeAttributeValue(fid, indeksAtributa, vrednost)

# ukoliko zelimo da dodamo atribut
# lejer.addAttribute(QgsField('god_zast', QVariant.Int))

# ukoliko zelimo da obrisemo atribut
# lejer.deleteAttribute(indeksAtributa)












import logging
import os

# izbacuje poruke Log Messages Panelu (donji desni ugao)
# koristi se QgsMessageLog klasa
# korisno za debagovanje 
QgsMessageLog.logMessage('Plugin je uspesno pokrenut', 'Moj_plugin', level=Qgis.Info)
QgsMessageLog.logMessage('Plugin sadrzi odredjene greske', 'Moj_plugin', level=Qgis.Warning)
QgsMessageLog.logMessage('Plugin je prestao sa radom', 'Moj_plugin', level=Qgis.Critical)


# koristeci ugradjenu pajtonovu biblioteku: logging

formatter = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
nazivLoga = r'D:/Fakultet/Master/Upravljanje_GIS_projektima/Projekat_PLUSLO/Podaci_QGIS/proba.log'
logging.basicConfig(filename=nazivLoga, level=logging.DEBUG, format=formatter)
logging.info('Ovaj info ide u fajl.')
logging.debug('Ovaj debug tekst takodje ide u fajl.')


# ukoliko zelimo da izbrisemo log fajl svaki put kada pokrenemo skriptu

if os.path.isfile(nazivLoga):
    with open(nazivLoga, 'w') as file:
        pass